<?php

namespace Offshore\Models;

class AccountOrder extends \Phalcon\Mvc\Model
{

    /**
     *
     * @var integer
     * @Primary
     * @Identity
     * @Column(type="integer", length=10, nullable=false)
     */
    protected $order_id;

    /**
     *
     * @var integer
     * @Column(type="integer", length=10, nullable=false)
     */
    protected $order_user_id;

    /**
     *
     * @var string
     * @Column(type="string", nullable=false)
     */
    protected $order_type;

    /**
     *
     * @var string
     * @Column(type="string", length=255, nullable=true)
     */
    protected $order_method;

    /**
     *
     * @var integer
     * @Column(type="integer", length=10, nullable=false)
     */
    protected $order_total;

    /**
     *
     * @var string
     * @Column(type="string", length=3, nullable=false)
     */
    protected $order_currency;

    /**
     *
     * @var string
     * @Column(type="string", length=255, nullable=true)
     */
    protected $order_promotion_code;

    /**
     *
     * @var double
     * @Column(type="double", nullable=true)
     */
    protected $order_promotion_amount;

    /**
     *
     * @var double
     * @Column(type="double", nullable=true)
     */
    protected $order_promotion_percent;

    /**
     *
     * @var double
     * @Column(type="double", nullable=true)
     */
    protected $order_promotion_total;

    /**
     *
     * @var integer
     * @Column(type="integer", length=11, nullable=true)
     */
    protected $order_payment_mid_id;

    /**
     *
     * @var string
     * @Column(type="string", length=255, nullable=true)
     */
    protected $order_payment_card_token;

    /**
     *
     * @var string
     * @Column(type="string", nullable=true)
     */
    protected $order_payment_method;

    /**
     *
     * @var integer
     * @Column(type="integer", length=10, nullable=false)
     */
    protected $order_insert_time;

    /**
     *
     * @var string
     * @Column(type="string", length=3, nullable=true)
     */
    protected $order_payment_currency;

    /**
     *
     * @var integer
     * @Column(type="integer", length=10, nullable=true)
     */
    protected $order_payment_total;

    /**
     *
     * @var integer
     * @Column(type="integer", length=11, nullable=true)
     */
    protected $order_payment_date;

    /**
     *
     * @var string
     * @Column(type="string", nullable=true)
     */
    protected $order_payment_isenrolled3d;

    /**
     *
     * @var string
     * @Column(type="string", nullable=true)
     */
    protected $order_payment_ispassed3d;

    /**
     *
     * @var integer
     * @Column(type="integer", length=11, nullable=true)
     */
    protected $order_exrate;

    /**
     *
     * @var integer
     * @Column(type="integer", length=11, nullable=true)
     */
    protected $order_exrate_date;

    /**
     *
     * @var string
     * @Column(type="string", nullable=false)
     */
    protected $order_status;

    /**
     *
     * @var string
     * @Column(type="string", length=255, nullable=true)
     */
    protected $order_fail_reason;

    /**
     *
     * @var string
     * @Column(type="string", length=255, nullable=true)
     */
    protected $order_shipping_name;

    /**
     *
     * @var string
     * @Column(type="string", length=3, nullable=true)
     */
    protected $order_shipping_country_code;

    /**
     *
     * @var string
     * @Column(type="string", length=255, nullable=true)
     */
    protected $order_shipping_address;

    /**
     *
     * @var string
     * @Column(type="string", length=255, nullable=true)
     */
    protected $order_shipping_tel;

    /**
     * Method to set the value of field order_id
     *
     * @param integer $order_id
     * @return $this
     */
    public function setOrderId($order_id)
    {
        $this->order_id = $order_id;

        return $this;
    }

    /**
     * Method to set the value of field order_user_id
     *
     * @param integer $order_user_id
     * @return $this
     */
    public function setOrderUserId($order_user_id)
    {
        $this->order_user_id = $order_user_id;

        return $this;
    }

    /**
     * Method to set the value of field order_type
     *
     * @param string $order_type
     * @return $this
     */
    public function setOrderType($order_type)
    {
        $this->order_type = $order_type;

        return $this;
    }

    /**
     * Method to set the value of field order_method
     *
     * @param string $order_method
     * @return $this
     */
    public function setOrderMethod($order_method)
    {
        $this->order_method = $order_method;

        return $this;
    }

    /**
     * Method to set the value of field order_total
     *
     * @param integer $order_total
     * @return $this
     */
    public function setOrderTotal($order_total)
    {
        $this->order_total = $order_total;

        return $this;
    }

    /**
     * Method to set the value of field order_currency
     *
     * @param string $order_currency
     * @return $this
     */
    public function setOrderCurrency($order_currency)
    {
        $this->order_currency = $order_currency;

        return $this;
    }

    /**
     * Method to set the value of field order_promotion_code
     *
     * @param string $order_promotion_code
     * @return $this
     */
    public function setOrderPromotionCode($order_promotion_code)
    {
        $this->order_promotion_code = $order_promotion_code;

        return $this;
    }

    /**
     * Method to set the value of field order_promotion_amount
     *
     * @param double $order_promotion_amount
     * @return $this
     */
    public function setOrderPromotionAmount($order_promotion_amount)
    {
        $this->order_promotion_amount = $order_promotion_amount;

        return $this;
    }

    /**
     * Method to set the value of field order_promotion_percent
     *
     * @param double $order_promotion_percent
     * @return $this
     */
    public function setOrderPromotionPercent($order_promotion_percent)
    {
        $this->order_promotion_percent = $order_promotion_percent;

        return $this;
    }

    /**
     * Method to set the value of field order_promotion_total
     *
     * @param double $order_promotion_total
     * @return $this
     */
    public function setOrderPromotionTotal($order_promotion_total)
    {
        $this->order_promotion_total = $order_promotion_total;

        return $this;
    }

    /**
     * Method to set the value of field order_payment_mid_id
     *
     * @param integer $order_payment_mid_id
     * @return $this
     */
    public function setOrderPaymentMidId($order_payment_mid_id)
    {
        $this->order_payment_mid_id = $order_payment_mid_id;

        return $this;
    }

    /**
     * Method to set the value of field order_payment_card_token
     *
     * @param string $order_payment_card_token
     * @return $this
     */
    public function setOrderPaymentCardToken($order_payment_card_token)
    {
        $this->order_payment_card_token = $order_payment_card_token;

        return $this;
    }

    /**
     * Method to set the value of field order_payment_method
     *
     * @param string $order_payment_method
     * @return $this
     */
    public function setOrderPaymentMethod($order_payment_method)
    {
        $this->order_payment_method = $order_payment_method;

        return $this;
    }

    /**
     * Method to set the value of field order_insert_time
     *
     * @param integer $order_insert_time
     * @return $this
     */
    public function setOrderInsertTime($order_insert_time)
    {
        $this->order_insert_time = $order_insert_time;

        return $this;
    }

    /**
     * Method to set the value of field order_payment_currency
     *
     * @param string $order_payment_currency
     * @return $this
     */
    public function setOrderPaymentCurrency($order_payment_currency)
    {
        $this->order_payment_currency = $order_payment_currency;

        return $this;
    }

    /**
     * Method to set the value of field order_payment_total
     *
     * @param integer $order_payment_total
     * @return $this
     */
    public function setOrderPaymentTotal($order_payment_total)
    {
        $this->order_payment_total = $order_payment_total;

        return $this;
    }

    /**
     * Method to set the value of field order_payment_date
     *
     * @param integer $order_payment_date
     * @return $this
     */
    public function setOrderPaymentDate($order_payment_date)
    {
        $this->order_payment_date = $order_payment_date;

        return $this;
    }

    /**
     * Method to set the value of field order_payment_isenrolled3d
     *
     * @param string $order_payment_isenrolled3d
     * @return $this
     */
    public function setOrderPaymentIsenrolled3d($order_payment_isenrolled3d)
    {
        $this->order_payment_isenrolled3d = $order_payment_isenrolled3d;

        return $this;
    }

    /**
     * Method to set the value of field order_payment_ispassed3d
     *
     * @param string $order_payment_ispassed3d
     * @return $this
     */
    public function setOrderPaymentIspassed3d($order_payment_ispassed3d)
    {
        $this->order_payment_ispassed3d = $order_payment_ispassed3d;

        return $this;
    }

    /**
     * Method to set the value of field order_exrate
     *
     * @param integer $order_exrate
     * @return $this
     */
    public function setOrderExrate($order_exrate)
    {
        $this->order_exrate = $order_exrate;

        return $this;
    }

    /**
     * Method to set the value of field order_exrate_date
     *
     * @param integer $order_exrate_date
     * @return $this
     */
    public function setOrderExrateDate($order_exrate_date)
    {
        $this->order_exrate_date = $order_exrate_date;

        return $this;
    }

    /**
     * Method to set the value of field order_status
     *
     * @param string $order_status
     * @return $this
     */
    public function setOrderStatus($order_status)
    {
        $this->order_status = $order_status;

        return $this;
    }

    /**
     * Method to set the value of field order_fail_reason
     *
     * @param string $order_fail_reason
     * @return $this
     */
    public function setOrderFailReason($order_fail_reason)
    {
        $this->order_fail_reason = $order_fail_reason;

        return $this;
    }

    /**
     * Method to set the value of field order_shipping_name
     *
     * @param string $order_shipping_name
     * @return $this
     */
    public function setOrderShippingName($order_shipping_name)
    {
        $this->order_shipping_name = $order_shipping_name;

        return $this;
    }

    /**
     * Method to set the value of field order_shipping_country_code
     *
     * @param string $order_shipping_country_code
     * @return $this
     */
    public function setOrderShippingCountryCode($order_shipping_country_code)
    {
        $this->order_shipping_country_code = $order_shipping_country_code;

        return $this;
    }

    /**
     * Method to set the value of field order_shipping_address
     *
     * @param string $order_shipping_address
     * @return $this
     */
    public function setOrderShippingAddress($order_shipping_address)
    {
        $this->order_shipping_address = $order_shipping_address;

        return $this;
    }

    /**
     * Method to set the value of field order_shipping_tel
     *
     * @param string $order_shipping_tel
     * @return $this
     */
    public function setOrderShippingTel($order_shipping_tel)
    {
        $this->order_shipping_tel = $order_shipping_tel;

        return $this;
    }

    /**
     * Returns the value of field order_id
     *
     * @return integer
     */
    public function getOrderId()
    {
        return $this->order_id;
    }

    /**
     * Returns the value of field order_user_id
     *
     * @return integer
     */
    public function getOrderUserId()
    {
        return $this->order_user_id;
    }

    /**
     * Returns the value of field order_type
     *
     * @return string
     */
    public function getOrderType()
    {
        return $this->order_type;
    }

    /**
     * Returns the value of field order_method
     *
     * @return string
     */
    public function getOrderMethod()
    {
        return $this->order_method;
    }

    /**
     * Returns the value of field order_total
     *
     * @return integer
     */
    public function getOrderTotal()
    {
        return $this->order_total;
    }

    /**
     * Returns the value of field order_currency
     *
     * @return string
     */
    public function getOrderCurrency()
    {
        return $this->order_currency;
    }

    /**
     * Returns the value of field order_promotion_code
     *
     * @return string
     */
    public function getOrderPromotionCode()
    {
        return $this->order_promotion_code;
    }

    /**
     * Returns the value of field order_promotion_amount
     *
     * @return double
     */
    public function getOrderPromotionAmount()
    {
        return $this->order_promotion_amount;
    }

    /**
     * Returns the value of field order_promotion_percent
     *
     * @return double
     */
    public function getOrderPromotionPercent()
    {
        return $this->order_promotion_percent;
    }

    /**
     * Returns the value of field order_promotion_total
     *
     * @return double
     */
    public function getOrderPromotionTotal()
    {
        return $this->order_promotion_total;
    }

    /**
     * Returns the value of field order_payment_mid_id
     *
     * @return integer
     */
    public function getOrderPaymentMidId()
    {
        return $this->order_payment_mid_id;
    }

    /**
     * Returns the value of field order_payment_card_token
     *
     * @return string
     */
    public function getOrderPaymentCardToken()
    {
        return $this->order_payment_card_token;
    }

    /**
     * Returns the value of field order_payment_method
     *
     * @return string
     */
    public function getOrderPaymentMethod()
    {
        return $this->order_payment_method;
    }

    /**
     * Returns the value of field order_insert_time
     *
     * @return integer
     */
    public function getOrderInsertTime()
    {
        return $this->order_insert_time;
    }

    /**
     * Returns the value of field order_payment_currency
     *
     * @return string
     */
    public function getOrderPaymentCurrency()
    {
        return $this->order_payment_currency;
    }

    /**
     * Returns the value of field order_payment_total
     *
     * @return integer
     */
    public function getOrderPaymentTotal()
    {
        return $this->order_payment_total;
    }

    /**
     * Returns the value of field order_payment_date
     *
     * @return integer
     */
    public function getOrderPaymentDate()
    {
        return $this->order_payment_date;
    }

    /**
     * Returns the value of field order_payment_isenrolled3d
     *
     * @return string
     */
    public function getOrderPaymentIsenrolled3d()
    {
        return $this->order_payment_isenrolled3d;
    }

    /**
     * Returns the value of field order_payment_ispassed3d
     *
     * @return string
     */
    public function getOrderPaymentIspassed3d()
    {
        return $this->order_payment_ispassed3d;
    }

    /**
     * Returns the value of field order_exrate
     *
     * @return integer
     */
    public function getOrderExrate()
    {
        return $this->order_exrate;
    }

    /**
     * Returns the value of field order_exrate_date
     *
     * @return integer
     */
    public function getOrderExrateDate()
    {
        return $this->order_exrate_date;
    }

    /**
     * Returns the value of field order_status
     *
     * @return string
     */
    public function getOrderStatus()
    {
        return $this->order_status;
    }

    /**
     * Returns the value of field order_fail_reason
     *
     * @return string
     */
    public function getOrderFailReason()
    {
        return $this->order_fail_reason;
    }

    /**
     * Returns the value of field order_shipping_name
     *
     * @return string
     */
    public function getOrderShippingName()
    {
        return $this->order_shipping_name;
    }

    /**
     * Returns the value of field order_shipping_country_code
     *
     * @return string
     */
    public function getOrderShippingCountryCode()
    {
        return $this->order_shipping_country_code;
    }

    /**
     * Returns the value of field order_shipping_address
     *
     * @return string
     */
    public function getOrderShippingAddress()
    {
        return $this->order_shipping_address;
    }

    /**
     * Returns the value of field order_shipping_tel
     *
     * @return string
     */
    public function getOrderShippingTel()
    {
        return $this->order_shipping_tel;
    }

    /**
     * Initialize method for model.
     */
    public function initialize()
    {
        $this->setSchema("offshore_merge_account");
    }

    /**
     * Returns table name mapped in the model.
     *
     * @return string
     */
    public function getSource()
    {
        return 'account_order';
    }

    /**
     * Allows to query a set of records that match the specified conditions
     *
     * @param mixed $parameters
     * @return AccountOrder[]|AccountOrder
     */
    public static function find($parameters = null)
    {
        return parent::find($parameters);
    }

    /**
     * Allows to query the first record that match the specified conditions
     *
     * @param mixed $parameters
     * @return AccountOrder
     */
    public static function findFirst($parameters = null)
    {
        return parent::findFirst($parameters);
    }

}
