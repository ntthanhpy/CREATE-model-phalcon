<?php

namespace Offshore\Models;

class OccContentCountry extends \Phalcon\Mvc\Model
{

    /**
     *
     * @var integer
     * @Primary
     * @Identity
     * @Column(type="integer", length=10, nullable=false)
     */
    protected $country_id;

    /**
     *
     * @var string
     * @Primary
     * @Column(type="string", length=5, nullable=false)
     */
    protected $country_location_country_code;

    /**
     *
     * @var string
     * @Column(type="string", length=3, nullable=true)
     */
    protected $country_country_code;

    /**
     *
     * @var string
     * @Column(type="string", length=3, nullable=true)
     */
    protected $country_state_code;

    /**
     *
     * @var string
     * @Column(type="string", length=255, nullable=false)
     */
    protected $country_name;

    /**
     *
     * @var string
     * @Column(type="string", length=255, nullable=false)
     */
    protected $country_keyword;

    /**
     *
     * @var string
     * @Column(type="string", length=255, nullable=false)
     */
    protected $country_title;

    /**
     *
     * @var string
     * @Column(type="string", length=255, nullable=false)
     */
    protected $country_meta_keyword;

    /**
     *
     * @var string
     * @Column(type="string", length=255, nullable=false)
     */
    protected $country_meta_description;

    /**
     *
     * @var string
     * @Column(type="string", nullable=true)
     */
    protected $country_content;

    /**
     *
     * @var integer
     * @Column(type="integer", length=11, nullable=false)
     */
    protected $country_insert_time;

    /**
     *
     * @var integer
     * @Column(type="integer", length=11, nullable=false)
     */
    protected $country_update_time;

    /**
     *
     * @var string
     * @Column(type="string", nullable=false)
     */
    protected $country_seo;

    /**
     *
     * @var integer
     * @Column(type="integer", length=10, nullable=false)
     */
    protected $country_order;

    /**
     *
     * @var string
     * @Column(type="string", nullable=false)
     */
    protected $country_active;

    /**
     * Method to set the value of field country_id
     *
     * @param integer $country_id
     * @return $this
     */
    public function setCountryId($country_id)
    {
        $this->country_id = $country_id;

        return $this;
    }

    /**
     * Method to set the value of field country_location_country_code
     *
     * @param string $country_location_country_code
     * @return $this
     */
    public function setCountryLocationCountryCode($country_location_country_code)
    {
        $this->country_location_country_code = $country_location_country_code;

        return $this;
    }

    /**
     * Method to set the value of field country_country_code
     *
     * @param string $country_country_code
     * @return $this
     */
    public function setCountryCountryCode($country_country_code)
    {
        $this->country_country_code = $country_country_code;

        return $this;
    }

    /**
     * Method to set the value of field country_state_code
     *
     * @param string $country_state_code
     * @return $this
     */
    public function setCountryStateCode($country_state_code)
    {
        $this->country_state_code = $country_state_code;

        return $this;
    }

    /**
     * Method to set the value of field country_name
     *
     * @param string $country_name
     * @return $this
     */
    public function setCountryName($country_name)
    {
        $this->country_name = $country_name;

        return $this;
    }

    /**
     * Method to set the value of field country_keyword
     *
     * @param string $country_keyword
     * @return $this
     */
    public function setCountryKeyword($country_keyword)
    {
        $this->country_keyword = $country_keyword;

        return $this;
    }

    /**
     * Method to set the value of field country_title
     *
     * @param string $country_title
     * @return $this
     */
    public function setCountryTitle($country_title)
    {
        $this->country_title = $country_title;

        return $this;
    }

    /**
     * Method to set the value of field country_meta_keyword
     *
     * @param string $country_meta_keyword
     * @return $this
     */
    public function setCountryMetaKeyword($country_meta_keyword)
    {
        $this->country_meta_keyword = $country_meta_keyword;

        return $this;
    }

    /**
     * Method to set the value of field country_meta_description
     *
     * @param string $country_meta_description
     * @return $this
     */
    public function setCountryMetaDescription($country_meta_description)
    {
        $this->country_meta_description = $country_meta_description;

        return $this;
    }

    /**
     * Method to set the value of field country_content
     *
     * @param string $country_content
     * @return $this
     */
    public function setCountryContent($country_content)
    {
        $this->country_content = $country_content;

        return $this;
    }

    /**
     * Method to set the value of field country_insert_time
     *
     * @param integer $country_insert_time
     * @return $this
     */
    public function setCountryInsertTime($country_insert_time)
    {
        $this->country_insert_time = $country_insert_time;

        return $this;
    }

    /**
     * Method to set the value of field country_update_time
     *
     * @param integer $country_update_time
     * @return $this
     */
    public function setCountryUpdateTime($country_update_time)
    {
        $this->country_update_time = $country_update_time;

        return $this;
    }

    /**
     * Method to set the value of field country_seo
     *
     * @param string $country_seo
     * @return $this
     */
    public function setCountrySeo($country_seo)
    {
        $this->country_seo = $country_seo;

        return $this;
    }

    /**
     * Method to set the value of field country_order
     *
     * @param integer $country_order
     * @return $this
     */
    public function setCountryOrder($country_order)
    {
        $this->country_order = $country_order;

        return $this;
    }

    /**
     * Method to set the value of field country_active
     *
     * @param string $country_active
     * @return $this
     */
    public function setCountryActive($country_active)
    {
        $this->country_active = $country_active;

        return $this;
    }

    /**
     * Returns the value of field country_id
     *
     * @return integer
     */
    public function getCountryId()
    {
        return $this->country_id;
    }

    /**
     * Returns the value of field country_location_country_code
     *
     * @return string
     */
    public function getCountryLocationCountryCode()
    {
        return $this->country_location_country_code;
    }

    /**
     * Returns the value of field country_country_code
     *
     * @return string
     */
    public function getCountryCountryCode()
    {
        return $this->country_country_code;
    }

    /**
     * Returns the value of field country_state_code
     *
     * @return string
     */
    public function getCountryStateCode()
    {
        return $this->country_state_code;
    }

    /**
     * Returns the value of field country_name
     *
     * @return string
     */
    public function getCountryName()
    {
        return $this->country_name;
    }

    /**
     * Returns the value of field country_keyword
     *
     * @return string
     */
    public function getCountryKeyword()
    {
        return $this->country_keyword;
    }

    /**
     * Returns the value of field country_title
     *
     * @return string
     */
    public function getCountryTitle()
    {
        return $this->country_title;
    }

    /**
     * Returns the value of field country_meta_keyword
     *
     * @return string
     */
    public function getCountryMetaKeyword()
    {
        return $this->country_meta_keyword;
    }

    /**
     * Returns the value of field country_meta_description
     *
     * @return string
     */
    public function getCountryMetaDescription()
    {
        return $this->country_meta_description;
    }

    /**
     * Returns the value of field country_content
     *
     * @return string
     */
    public function getCountryContent()
    {
        return $this->country_content;
    }

    /**
     * Returns the value of field country_insert_time
     *
     * @return integer
     */
    public function getCountryInsertTime()
    {
        return $this->country_insert_time;
    }

    /**
     * Returns the value of field country_update_time
     *
     * @return integer
     */
    public function getCountryUpdateTime()
    {
        return $this->country_update_time;
    }

    /**
     * Returns the value of field country_seo
     *
     * @return string
     */
    public function getCountrySeo()
    {
        return $this->country_seo;
    }

    /**
     * Returns the value of field country_order
     *
     * @return integer
     */
    public function getCountryOrder()
    {
        return $this->country_order;
    }

    /**
     * Returns the value of field country_active
     *
     * @return string
     */
    public function getCountryActive()
    {
        return $this->country_active;
    }

    /**
     * Initialize method for model.
     */
    public function initialize()
    {
        $this->setSchema("offshore_merge");
    }

    /**
     * Returns table name mapped in the model.
     *
     * @return string
     */
    public function getSource()
    {
        return 'occ_content_country';
    }

    /**
     * Allows to query a set of records that match the specified conditions
     *
     * @param mixed $parameters
     * @return OccContentCountry[]|OccContentCountry
     */
    public static function find($parameters = null)
    {
        return parent::find($parameters);
    }

    /**
     * Allows to query the first record that match the specified conditions
     *
     * @param mixed $parameters
     * @return OccContentCountry
     */
    public static function findFirst($parameters = null)
    {
        return parent::findFirst($parameters);
    }

}
