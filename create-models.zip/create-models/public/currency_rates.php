<?php

$_PartnerId = 'A1D97D51-0F3C-45C9-A808-7554364BB288';
$_TranId = uniqid();
$_TranDate = date('YmdHis');
$_Client = '630591';
$_TranType = '103';
$_CurCode = 'EUR';
$str = $_PartnerId . $_TranId . $_TranDate . $_TranType . $_CurCode . $_PartnerId;

$xml = "<?xml version=\"1.0\" encoding=\"utf-8\"?>
<request>
 <partnerid>".$_PartnerId."</partnerid>
 <tranid>".$_TranId."</tranid>
 <trandate>".$_TranDate."</trandate>
 <trantype>".$_TranType."</trantype>
 <curcode>".$_CurCode."</curcode>
 <margin>S</margin>
 <checksum>".sha1($str)."</checksum>
</request>";

echo $xml."\n";

$test_URL       = 'https://dsbc-stage.megasol.net:8443/c3api/dsbc/dotransaction.mwsapi';
$certfile       = '/boapitest.pem';
$certPass       = 'bindsbcf@bo#153';

$ch = curl_init();

curl_setopt( $ch, CURLOPT_URL, $test_URL );
curl_setopt( $ch, CURLOPT_RETURNTRANSFER, 1 );
curl_setopt( $ch, CURLOPT_SSL_VERIFYPEER, false);
curl_setopt( $ch, CURLOPT_SSL_VERIFYHOST, false);
curl_setopt( $ch, CURLOPT_SSLCERT, getcwd() . $certfile );
curl_setopt( $ch, CURLOPT_SSLCERTPASSWD, $certPass);
curl_setopt( $ch, CURLOPT_POST, 1 );
curl_setopt( $ch, CURLOPT_HTTPHEADER, array( 'Content-Type: text/xml' ) );
curl_setopt( $ch, CURLOPT_POSTFIELDS, $xml );
$ch_result = curl_exec( $ch );

// Check for errors
if ( curl_errno($ch) ) {
    $ch_result = 'cURL ERROR -> ' . curl_errno($ch) . ': ' . curl_error($ch);
}

curl_close( $ch );
echo "<pre>";
var_dump(htmlentities($ch_result));
?>