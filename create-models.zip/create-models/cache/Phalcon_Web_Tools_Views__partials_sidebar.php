<aside class="main-sidebar">
    <section class="sidebar">
        <?= $this->sidebar->render() ?>
    </section>
</aside>
