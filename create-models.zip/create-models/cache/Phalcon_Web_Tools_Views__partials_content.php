<section class="content">
    <?= $this->getContent() ?>
</section>
