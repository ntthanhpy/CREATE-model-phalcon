a:20:{i:0;s:555:"<?= $this->tag->getDoctype() ?>
<html>
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <?= $this->tag->getTitle() ?>
    <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
    <meta content="<?= $phalcon_team ?>" name="author">
    <link rel="shortcut icon" href="/favicon.ico?v=<?= $ptools_version ?>">
    <?= $this->tag->stylesheetLink('https://fonts.googleapis.com/css?family=Roboto:400,500,700,900&subset=latin,cyrillic-ext,cyrillic', false) ?>
    ";s:10:"head_icons";a:5:{i:0;a:4:{s:4:"type";i:357;s:5:"value";s:9:"
        ";s:4:"file";s:67:"E:\phalcon-tools\scripts\Phalcon\Web\Tools\Views\/layouts/base.volt";s:4:"line";i:12;}i:1;a:4:{s:4:"type";i:359;s:4:"expr";a:5:{s:4:"type";i:350;s:4:"name";a:4:{s:4:"type";i:265;s:5:"value";s:15:"stylesheet_link";s:4:"file";s:67:"E:\phalcon-tools\scripts\Phalcon\Web\Tools\Views\/layouts/base.volt";s:4:"line";i:12;}s:9:"arguments";a:2:{i:0;a:3:{s:4:"expr";a:4:{s:4:"type";i:260;s:5:"value";s:82:"https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.5.0/css/font-awesome.min.css";s:4:"file";s:67:"E:\phalcon-tools\scripts\Phalcon\Web\Tools\Views\/layouts/base.volt";s:4:"line";i:12;}s:4:"file";s:67:"E:\phalcon-tools\scripts\Phalcon\Web\Tools\Views\/layouts/base.volt";s:4:"line";i:12;}i:1;a:3:{s:4:"expr";a:3:{s:4:"type";i:262;s:4:"file";s:67:"E:\phalcon-tools\scripts\Phalcon\Web\Tools\Views\/layouts/base.volt";s:4:"line";i:12;}s:4:"file";s:67:"E:\phalcon-tools\scripts\Phalcon\Web\Tools\Views\/layouts/base.volt";s:4:"line";i:12;}}s:4:"file";s:67:"E:\phalcon-tools\scripts\Phalcon\Web\Tools\Views\/layouts/base.volt";s:4:"line";i:12;}s:4:"file";s:67:"E:\phalcon-tools\scripts\Phalcon\Web\Tools\Views\/layouts/base.volt";s:4:"line";i:13;}i:2;a:4:{s:4:"type";i:357;s:5:"value";s:9:"
        ";s:4:"file";s:67:"E:\phalcon-tools\scripts\Phalcon\Web\Tools\Views\/layouts/base.volt";s:4:"line";i:13;}i:3;a:4:{s:4:"type";i:359;s:4:"expr";a:5:{s:4:"type";i:350;s:4:"name";a:4:{s:4:"type";i:265;s:5:"value";s:15:"stylesheet_link";s:4:"file";s:67:"E:\phalcon-tools\scripts\Phalcon\Web\Tools\Views\/layouts/base.volt";s:4:"line";i:13;}s:9:"arguments";a:2:{i:0;a:3:{s:4:"expr";a:4:{s:4:"type";i:260;s:5:"value";s:74:"https://cdnjs.cloudflare.com/ajax/libs/ionicons/2.0.1/css/ionicons.min.css";s:4:"file";s:67:"E:\phalcon-tools\scripts\Phalcon\Web\Tools\Views\/layouts/base.volt";s:4:"line";i:13;}s:4:"file";s:67:"E:\phalcon-tools\scripts\Phalcon\Web\Tools\Views\/layouts/base.volt";s:4:"line";i:13;}i:1;a:3:{s:4:"expr";a:3:{s:4:"type";i:262;s:4:"file";s:67:"E:\phalcon-tools\scripts\Phalcon\Web\Tools\Views\/layouts/base.volt";s:4:"line";i:13;}s:4:"file";s:67:"E:\phalcon-tools\scripts\Phalcon\Web\Tools\Views\/layouts/base.volt";s:4:"line";i:13;}}s:4:"file";s:67:"E:\phalcon-tools\scripts\Phalcon\Web\Tools\Views\/layouts/base.volt";s:4:"line";i:13;}s:4:"file";s:67:"E:\phalcon-tools\scripts\Phalcon\Web\Tools\Views\/layouts/base.volt";s:4:"line";i:14;}i:4;a:4:{s:4:"type";i:357;s:5:"value";s:5:"
    ";s:4:"file";s:67:"E:\phalcon-tools\scripts\Phalcon\Web\Tools\Views\/layouts/base.volt";s:4:"line";i:14;}}i:1;s:302:"
    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
    <?= $this->assets->outputJs('js_ie') ?>
    <![endif]-->
    <?= $this->assets->outputCss('main_css') ?>
    ";s:11:"head_custom";N;i:2;s:8:"
</head>";s:10:"body_start";a:1:{i:0;a:4:{s:4:"type";i:357;s:5:"value";s:53:"<body class="hold-transition skin-blue sidebar-mini">";s:4:"file";s:67:"E:\phalcon-tools\scripts\Phalcon\Web\Tools\Views\/layouts/base.volt";s:4:"line";i:25;}}s:13:"wrapper_start";a:1:{i:0;a:4:{s:4:"type";i:357;s:5:"value";s:21:"<div class="wrapper">";s:4:"file";s:67:"E:\phalcon-tools\scripts\Phalcon\Web\Tools\Views\/layouts/base.volt";s:4:"line";i:28;}}s:6:"header";N;i:3;s:9:"
        ";s:7:"sidebar";N;i:4;s:9:"
        ";s:7:"content";N;i:5;s:9:"
        ";s:6:"footer";N;i:6;s:9:"
        ";s:13:"sidebar_right";N;s:11:"wrapper_end";a:1:{i:0;a:4:{s:4:"type";i:357;s:5:"value";s:53:"<div class="control-sidebar-bg"></div>
        </div>";s:4:"file";s:67:"E:\phalcon-tools\scripts\Phalcon\Web\Tools\Views\/layouts/base.volt";s:4:"line";i:37;}}s:9:"footer_js";N;s:8:"body_end";a:1:{i:0;a:4:{s:4:"type";i:357;s:5:"value";s:7:"</body>";s:4:"file";s:67:"E:\phalcon-tools\scripts\Phalcon\Web\Tools\Views\/layouts/base.volt";s:4:"line";i:41;}}i:7;s:8:"</html>
";}