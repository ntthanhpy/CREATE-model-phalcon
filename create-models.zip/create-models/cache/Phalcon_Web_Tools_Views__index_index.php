<section class="invoice">
    <div class="row">
        <div class="col-xs-12">
            <h2 class="page-header">Welcome to WebTools</h2>
        </div>
    </div>
    <div class="row">
        <div class="col-xs-12">
            <p>
                This application allows you to use
                <?= $this->tag->linkTo([$phalcon_url, 'Phalcon', false, 'target' => '_blank']) ?>&nbsp;<?= $this->tag->linkTo([$devtools_url, 'Developer Tools', false, 'target' => '_blank']) ?> using a web interface.
            </p>
        </div>
    </div>
</section>
