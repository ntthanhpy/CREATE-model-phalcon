<?php
//$_SERVER['REMOTE_ADDR'] = '14.161.2.3';
!defined('LOCAL_RECAPTCHA') && define('LOCAL_RECAPTCHA',true);
!defined('EMAIL_TEST_MODE') && define('EMAIL_TEST_MODE', true);
!defined('EMAIL_TEST_EMAIL') && define('EMAIL_TEST_EMAIL', 'cong@bin.com.vn');
!defined('EMAIL_SUBJECT_PREFIX') && define('EMAIL_SUBJECT_PREFIX', 'LOCAL_');
!defined('LOCAL_RECAPTCHA') && define('LOCAL_RECAPTCHA',true);
!defined('URL_SITE') && define('URL_SITE', 'http://offshorecompanycorpcom.local');
if (!defined('RECAPTCHA_SITEKEY')) {
    define('RECAPTCHA_SITEKEY', '6LdBF3oUAAAAAMaxRHIOZLzMM05w_muyhtvXitI4');
}
if (!defined('RECAPTCHA_SECRETKEY')) {
    define('RECAPTCHA_SECRETKEY', '6LdBF3oUAAAAALOdQoMI1XxzZ_qUm72IqLoZTF-4');
}
if (!defined('QR_CODE_MODE')) {
    define('QR_CODE_MODE', true);
}
return new \Phalcon\Config(array(
    'database' => array(
        'adapter'  => 'Mysql',
        'host'     => 'localhost',
        'username' => 'root',
        'password' => '',
        'name'     => 'offshore_merge',
        'charset'  => 'utf8'
    ),
    'database_general' => array(
        'adapter'  => 'Mysql',
        'host'     => 'localhost',
        'username' => 'root',
        'password' => '',
        'name'     => 'general',
        'charset'  => 'utf8'
    )
));
